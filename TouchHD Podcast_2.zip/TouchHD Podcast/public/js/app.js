$(document).ready(function(){
    var ads = [];
    var currentVideo = 0;

    $(this).on("ajaxStart", function(e){
        $(".loader").removeClass("hide");
    });

    player = videojs('my-video', {
        techOrder: ['html5', 'flash'],
        autoplay: false
    });

    /*****************************
     *      INITIALISE ADS       *
    ******************************/

    $.ajax({
        url: "https://touch-hd.firebaseio.com/Ad.json",
        success: function(data){
            ads = data;
        },
        global:false
    });

    player.ads();

    player.on('contentupdate', function(){
        player.trigger('adsready');
    });

    player.on('readyforpreroll',function(){
        var adToLoad = ads[Math.round(Math.random() * ads.length)];
        createAdLink(adToLoad.webLink, adToLoad.title);
        player.ads.startLinearAdMode();
        player.src(adToLoad.url);
        addSkipButton();
        player.one('adended',function(){
            player.ads.endLinearAdMode();
            removeAdButtons();
            $(".vjs-loading-spinner")[0].css({"display":"none"});

        });
        player.one("adskip", function(){
            player.ads.endLinearAdMode();
            removeAdButtons();
            $(".vjs-loading-spinner").css({"display":"none"});
        });
    });

    function createAdLink(adLInk, adTitle){
        $("#my-video").append("<a href='" + adLInk + "' target='blank' id='ad-link'>" + adTitle + " <i class='fa fa-external-link' aria-hidden='true'></i></a>")
        $("#ad-link").click(function(){
            player.pause();
        });
    }

    function addSkipButton(){
        var adTimer = setInterval(function(){
            if (Math.round(player.currentTime()) >= 5)
            {
                $("#my-video").append("<div id='skip-ad'><span id='skip-ad--button'>Skip ad <i class='fa fa-step-forward' aria-hidden='true'></i></span></div>")
                $("#skip-ad").click(function(){
                    player.trigger("adskip");
                });
                clearInterval(adTimer);
            }
        }, 1000);
    }

    function mapNumber(x, in_min, in_max, out_min, out_max)
    {
        return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
    }

    function removeAdButtons(){
        $("#ad-link").remove();
        $("#skip-ad").remove();
    }



/***********************************
*
***********************************/

    $.ajax({
        url: "https://touch-hd.firebaseio.com/videos.json",
        success: function(videos){
           // loadAds();
            loadPlaylist(videos)
        },
        complete: function(){
          $(".loader").addClass("hide");
        },
        
    });

    function changeSource(src, title) {
        player.pause();
        player.currentTime(0);

        player.src(src);

        player.ready(function() {
            this.one('loadeddata', videojs.bind(this, function() {
                this.currentTime(0);
            }));

            this.load();
            this.play();
            $(".controls-wrapper .video-details .title").text(title);
        });
    }

    var loadPlaylist = function(videos){
        videos.map(function(video, index){
            if(video !== null)
            {
                addVideo(video, index);
            }
        });
        changeSource({
            type: "video/mp4",
            src: videos[currentVideo + 1].src,
        }, videos[currentVideo + 1].title);
        
        $(".video--list-item#1").addClass("active");

        $(".video--list-item").click(function(){
            if(player.ads.isInAdMode())
            {
                $("#toast #text").text("Cannot change video while ad is playing");
                $("#toast").css({"bottom":"10px"});
                setTimeout(function(){
                    $("#toast").css({"bottom":"-100px"});
                }, 3000);
                return;
            }
            changeSource({
            type:"video/mp4",
            src:$(this)[0].dataset.src
            }, $(this)[0].dataset.title);
            $(".video--list-item.active").removeClass("active");
            $(this).addClass("active");
            currentVideo =  $(this)[0].attributes.id.value;
            $('html, body').animate({scrollTop : 0},800);
        });
    }

    player.on("ended", function(){
        if($("#auto-next")[0].checked === false) return (false);
        currentVideo++;
        $(".video--list-item").removeClass("active");
        var video = $(".video--list-item")[currentVideo];
        changeSource({
            type:"video/mp4",
            src:video.dataset.src
        },video.dataset.title);
        $(".video--list-item#" + video.attributes.id.value).addClass("active");
    });

    player.on("pause", function(){
        $(".vjs-big-play-button").css({"display":"block"});
    });

    player.on("play", function(){
        $(".vjs-big-play-button").css({"display":"none"});
    });

    $("video").on("touchstart", function(e){
        e.preventDefault();
        if(player.paused())
        {
            player.play();
        }else{
            player.pause();
        }
    });

    var addVideo = function(video, index){
       var playlist =  $(".playlist");
       var vidHTML = "<div class='video--list-item' data-src=" + video.src +
       " data-title='" + video.title + "'" +
       " data-index='" + index + "'" + 
       " id='" + index +"'>" +
        "<img src=" + video.thumbnail + ">" +
        "<div class='info'>"+
            "<p class='title'>" + video.title + "</p>"+
            "<p class='video-stats'><span>24 May 2017</span>.<span>1.5K Views</span></p>" +
        "</div>" +
        "</div>";
        playlist.append(vidHTML);
    }

    $("#search-sm--btn").click(function(){
        $(this).hide();
        $("#logo").hide();
        $("#search-sm").addClass("search-sm--visible").focus();
    });
    $("#search-sm").blur(function(){
        $(this).removeClass("search-sm--visible");
        $("#logo").show();
        $("#search-sm--btn").show();
    });

    $("#search-form").submit(function(e){
        e.preventDefault();
        console.log("trying to submit");
    });

    function searchPodcast(searchString){
        //make ajax request to search
    }

    /******************************
     *  TOGGLE TABS
    *******************************/
    $(".player-tabbar .tab").click(function(){
        $(".player-tabbar .tab").removeClass("active-tab");
        $(this).addClass("active-tab");
    });
});